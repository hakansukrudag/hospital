"#Rock-Paper-Scissors":

This project is just a copy of a video online tutorial on web development (see below for link), and is used to understand the very basics of web development. 

This is a single-player game, in which once you have made your choice, you could see whether you win, lose or the match ends in a draw
based on what the computer(depicting the opponent) has chosen. The score-board keeps account of how many games you have won and lost.

Game Rules:-
It's a pretty simple hand game usually played between two players. 
Rock beats scissors, scissors beats paper and paper beats rock.
If both players choose the same thing, it results in a draw. 

Video Reference:-
https://youtu.be/jaVNP3nIAv0
